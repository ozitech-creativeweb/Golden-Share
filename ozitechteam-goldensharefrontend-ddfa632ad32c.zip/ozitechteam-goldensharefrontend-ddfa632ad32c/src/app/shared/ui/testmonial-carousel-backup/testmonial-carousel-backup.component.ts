import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testmonial-carousel-backup',
  templateUrl: './testmonial-carousel-backup.component.html',
  styleUrls: ['./testmonial-carousel-backup.component.scss']
})
export class TestmonialCarouselBackupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
