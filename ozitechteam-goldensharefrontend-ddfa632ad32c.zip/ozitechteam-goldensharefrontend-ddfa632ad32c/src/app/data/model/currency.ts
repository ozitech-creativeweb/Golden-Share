export class Currency {
    name: string;
    symbol: string;
}
