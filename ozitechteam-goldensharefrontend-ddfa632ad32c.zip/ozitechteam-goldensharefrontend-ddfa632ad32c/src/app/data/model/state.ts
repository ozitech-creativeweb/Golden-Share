export class State {
    name: string;
    capital: string;
}
