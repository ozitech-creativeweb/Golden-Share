export class UserLoginActivity {
    id: number;
    login_id: number;
    username: string;
    ip: string;
    browser: string;
    os: string;
    created_at: Date;
    updated_at: Date;
}
