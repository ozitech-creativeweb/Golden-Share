export class UserSocial {
    id: number;
    login_id: number;
    gender: string;
    dob: string;
    website: string;
    facebook: string;
    twitter: string;
    linkedin: string;
    google: string;
    stackoverflow: string;
    created_at: Date;
    updated_at: Date;
}
