export class Country {
    name: string;
    code: string;
    symbol: string;
    dailing: string;
    iso: string;
}
