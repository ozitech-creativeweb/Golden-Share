import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class FormService {
  dismiss(inputFields: any[]) {
    // Don't do anything!
  }
}
