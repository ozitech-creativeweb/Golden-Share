import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ConfigService {
  private subject = new Subject<any>();

  get adminURL() {
    return 'administrator';
  }

  get isDemo() {
    return false;
  }

  private tempURL() {
    let url, hostname;
    hostname = window.location.hostname;
    hostname = hostname.replace('http://', '').replace('https://', '');
    const target = hostname.substring(0, 4);
    if (target === 'www.') {
      url = hostname;
    } else {
      url = 'www.' + hostname;
    }
    return url;
  }

  base_url() {
    // return 'https://goldenshare.creativeweb.com.ng/backend/';
    // return 'https://localhost/goldenShare/';
    return 'https://ourbank.online/backend/';
    // return 'https://goldenshares.org/backend-premium/';
    // return 'https://auctionfx-test.creativeweb.com.ng/backend/';
    // return 'https://' + this.tempURL() + '/backend/'; // Production
    // return 'https://auctionfx.creativeweb.com.ng/backend/';
    // return 'https://www.' + window.location.hostname + '/backend/'; // Production
    // return 'https://www.bidauctionlive.co.za/backend/';
    // return 'https://www.millionairesplace.co.za/backend/';
    // return 'https://http://www.bidauctionlive.co.za/backend/';
    // return 'https://www.azuritecoin.com/backend/';
    // return 'https://www.takakitchens.co.za/backend/';
    // return 'https://localhost/sidgoon/';
    // return 'https://creativeweb.com.ng/system/wagAuction/server/v01/';
  }

  bankInfo() {
    return {
      name: 'Oziconnect Global Network Limited',
      ngn: 2032394126,
      usd: 2032394061,
      bank: 'First Bank Plc',
      swift: 'FBNINGLA',
      instructions: 'For payment confirmation, please send proof of payment to payment@oziconnect.com',
    };
  }

  clearnUrl(str) {
    if (str) {
      return str.replace(/[^a-zA-Z0-9 &+,._-]/g, '').split('&').join('and')
        .split(' + ').join('-').split('+ ').join('-').split('+').join('-')
        .split(', ').join('-').split(',').join('-')
        .split('  ').join('-').split(' - ').join('-').split(' ').join('-')
        .toLowerCase();
    }
  }

  getTitleCase(str) {
    return str.replace(/(^|\s)\S/g, function(t) { return t.toUpperCase(); });
  }

  getRandomString(lengthCnt) {
    let result = '', i;
    const chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    for (i = lengthCnt; i > 0; --i) {
      result += chars[Math.floor(Math.random() * chars.length)];
    }
    return result;
  }

  isRootAdmin(admin) {
    if (admin && admin.username === 'administrator') {
      return true;
    } else {
      return false;
    }
  }

}



// $2y$10$4fdyWgJZdIhBelKusvevFeje8PlSttLmMzYuSGch5RPug5Wj1Hck.

// 33,814


// 15, 208
