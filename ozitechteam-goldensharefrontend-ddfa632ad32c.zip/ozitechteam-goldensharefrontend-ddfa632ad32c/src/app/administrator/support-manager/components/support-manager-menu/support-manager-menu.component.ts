import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-support-manager-menu',
  templateUrl: './support-manager-menu.component.html',
  styleUrls: ['./support-manager-menu.component.scss']
})
export class SupportManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
