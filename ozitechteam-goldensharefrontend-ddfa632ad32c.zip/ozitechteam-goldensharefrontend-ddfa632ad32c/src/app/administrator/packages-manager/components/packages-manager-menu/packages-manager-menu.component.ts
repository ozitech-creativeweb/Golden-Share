import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-packages-manager-menu',
  templateUrl: './packages-manager-menu.component.html',
  styleUrls: ['./packages-manager-menu.component.scss']
})
export class PackagesManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
