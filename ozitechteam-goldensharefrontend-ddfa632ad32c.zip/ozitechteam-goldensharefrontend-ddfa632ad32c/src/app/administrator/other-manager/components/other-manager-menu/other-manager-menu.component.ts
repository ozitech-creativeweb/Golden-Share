import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-other-manager-menu',
  templateUrl: './other-manager-menu.component.html',
  styleUrls: ['./other-manager-menu.component.scss']
})
export class OtherManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
