import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-activity-manager-menu',
  templateUrl: './activity-manager-menu.component.html',
  styleUrls: ['./activity-manager-menu.component.scss']
})
export class ActivityManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
