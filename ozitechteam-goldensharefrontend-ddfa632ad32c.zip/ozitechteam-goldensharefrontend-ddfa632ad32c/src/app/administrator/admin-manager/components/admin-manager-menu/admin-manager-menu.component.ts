import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-manager-menu',
  templateUrl: './admin-manager-menu.component.html',
  styleUrls: ['./admin-manager-menu.component.scss']
})
export class AdminManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
