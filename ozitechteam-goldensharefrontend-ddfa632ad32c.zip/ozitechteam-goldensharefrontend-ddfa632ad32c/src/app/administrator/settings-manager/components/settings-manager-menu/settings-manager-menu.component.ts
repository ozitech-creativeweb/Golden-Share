import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings-manager-menu',
  templateUrl: './settings-manager-menu.component.html',
  styleUrls: ['./settings-manager-menu.component.scss']
})
export class SettingsManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
