import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-manager-menu',
  templateUrl: './user-manager-menu.component.html',
  styleUrls: ['./user-manager-menu.component.scss']
})
export class UserManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
