import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-add-address',
  templateUrl: './user-add-address.component.html',
  styleUrls: ['./user-add-address.component.scss']
})
export class UserAddAddressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
