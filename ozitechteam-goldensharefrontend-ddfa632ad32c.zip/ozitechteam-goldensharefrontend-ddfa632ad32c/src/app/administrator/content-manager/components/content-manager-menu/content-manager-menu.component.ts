import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-manager-menu',
  templateUrl: './content-manager-menu.component.html',
  styleUrls: ['./content-manager-menu.component.scss']
})
export class ContentManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
