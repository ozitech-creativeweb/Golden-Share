import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news-manager-menu',
  templateUrl: './news-manager-menu.component.html',
  styleUrls: ['./news-manager-menu.component.scss']
})
export class NewsManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
