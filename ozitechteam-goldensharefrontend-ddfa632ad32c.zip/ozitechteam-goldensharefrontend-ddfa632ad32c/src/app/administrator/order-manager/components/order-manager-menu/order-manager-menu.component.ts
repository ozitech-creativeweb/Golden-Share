import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-manager-menu',
  templateUrl: './order-manager-menu.component.html',
  styleUrls: ['./order-manager-menu.component.scss']
})
export class OrderManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
