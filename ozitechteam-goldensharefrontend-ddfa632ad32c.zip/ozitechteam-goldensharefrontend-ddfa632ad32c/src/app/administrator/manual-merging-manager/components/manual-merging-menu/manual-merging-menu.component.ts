import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manual-merging-menu',
  templateUrl: './manual-merging-menu.component.html',
  styleUrls: ['./manual-merging-menu.component.scss']
})
export class ManualMergingMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
