import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawal-manager-menu',
  templateUrl: './withdrawal-manager-menu.component.html',
  styleUrls: ['./withdrawal-manager-menu.component.scss']
})
export class WithdrawalManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
