import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-manager-menu',
  templateUrl: './product-manager-menu.component.html',
  styleUrls: ['./product-manager-menu.component.scss']
})
export class ProductManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
