import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donation-manager-menu',
  templateUrl: './donation-manager-menu.component.html',
  styleUrls: ['./donation-manager-menu.component.scss']
})
export class DonationManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
