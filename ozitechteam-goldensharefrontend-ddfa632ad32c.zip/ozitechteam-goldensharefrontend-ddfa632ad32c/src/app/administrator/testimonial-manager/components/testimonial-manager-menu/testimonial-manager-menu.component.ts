import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testimonial-manager-menu',
  templateUrl: './testimonial-manager-menu.component.html',
  styleUrls: ['./testimonial-manager-menu.component.scss']
})
export class TestimonialManagerMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
